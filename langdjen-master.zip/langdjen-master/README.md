# langdjen
Language Generator

## todo
+ conditionals: for example, 82A (Order of Subject and Verb) and 83A (Order of Object and Verb) given 81\[A\] (Order of Subject, Object and Verb)
+ also, probabilistic conditionals: data mining for correlations